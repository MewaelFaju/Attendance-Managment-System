require('dotenv/config');

const config = {
  port: Number(process.env.PORT) || 4000,
  mongoUri: process.env.MONGO_URI || '',
  jwtSecret: process.env.JWT_SECRET || 'dev-only-secret-change-me',
  clientOrigin: process.env.CLIENT_ORIGIN || 'http://localhost:5173',
  adminEmail: (process.env.ADMIN_EMAIL || 'admin@playverse.local').toLowerCase(),
  adminPassword: process.env.ADMIN_PASSWORD || 'Admin123!',
};

module.exports = { config };
